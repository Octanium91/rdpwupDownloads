more info: https://www.octaniumsw.site/2019/04/rdp-wrapper-confg-update-tool-en.html
new version: more info: https://www.octaniumsw.site/2019/04/rdp-wrapper-confg-update-tool-en.html